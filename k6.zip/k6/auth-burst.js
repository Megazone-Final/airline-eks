import http from 'k6/http';
import { check } from 'k6';
import { BASE_URL, REQUEST_TIMEOUT, parseNumberEnv } from './common.js';

const startRate = parseNumberEnv('AUTH_BURST_START_RATE', 50);
const stepRate = parseNumberEnv('AUTH_BURST_STEP_RATE', 100);
const steps = parseNumberEnv('AUTH_BURST_STEPS', 5);
const stepDuration = __ENV.AUTH_BURST_STEP_DURATION || '2m';
const preAllocatedVUs = parseNumberEnv('AUTH_BURST_PRE_ALLOCATED_VUS', 100);
const maxVUs = parseNumberEnv('AUTH_BURST_MAX_VUS', 1000);
const email = (__ENV.LOGIN_EMAIL || 'loadtest-nonexistent@izones.cloud').trim();
const password = __ENV.LOGIN_PASSWORD || 'wrong-password';

const stages = Array.from({ length: Math.max(1, steps) }, (_, index) => {
  return {
    target: startRate + stepRate * (index + 1),
    duration: stepDuration,
  };
});

export const options = {
  discardResponseBodies: true,
  scenarios: {
    auth_login_burst: {
      executor: 'ramping-arrival-rate',
      startRate,
      timeUnit: '1s',
      preAllocatedVUs,
      maxVUs,
      stages,
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.05'],
    checks: ['rate>0.95'],
    'http_req_duration{endpoint:auth-login-burst}': ['p(95)<1500'],
  },
};

export default function () {
  const response = http.post(
    `${BASE_URL}/api/auth/users/login`,
    JSON.stringify({
      email,
      password,
    }),
    {
      headers: {
        'Content-Type': 'application/json',
      },
      tags: {
        endpoint: 'auth-login-burst',
      },
      timeout: REQUEST_TIMEOUT,
    }
  );

  check(response, {
    'login returns 200 or 401': (res) => res.status === 200 || res.status === 401,
  });
}
