import http from 'k6/http';
import { check, sleep } from 'k6';

const BASE_URL = (__ENV.BASE_URL || 'https://izones.cloud').replace(/\/+$/, '');
const TARGET_PATH =
  __ENV.TARGET_PATH || '/api/flight?departure=ICN&arrival=NRT&passengers=1';
const VUS = Number(__ENV.VUS || 10);
const DURATION = __ENV.DURATION || '1m';
const SLEEP_SECONDS = Number(__ENV.SLEEP_SECONDS || 1);

export const options = {
  vus: VUS,
  duration: DURATION,
  thresholds: {
    http_req_failed: ['rate<0.05'],
    checks: ['rate>0.95'],
    http_req_duration: ['p(95)<500'],
  },
};

export default function () {
  const response = http.get(`${BASE_URL}${TARGET_PATH}`, {
    tags: { endpoint: 'simple-load' },
    timeout: __ENV.REQUEST_TIMEOUT || '10s',
  });

  check(response, {
    'status is 200': (r) => r.status === 200,
  });

  sleep(SLEEP_SECONDS);
}

