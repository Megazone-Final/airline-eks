# k6 scripts

These scripts target the public API exposed by `izones.cloud`.

## Required

- `k6` installed locally
- at least one test account:
  - `USER_EMAIL`
  - `USER_PASSWORD`

You can also provide a pool with `USER_EMAILS=user1@example.com,user2@example.com`.

## Scripts

- `k6/simple-load.js`: simplest load test for one endpoint
- `k6/search.js`: flight search and flight detail
- `k6/auth.js`: login, profile, logout
- `k6/auth-burst.js`: high-rate login burst for HPA/Karpenter verification
- `k6/auth-search-mix.js`: auth burst + public flight search burst in one run
- `k6/checkout.js`: login, search, flight detail, payment, payment detail
- `k6/mypage.js`: login, reservations list, payments list

## Examples

```bash
k6 run \
  -e BASE_URL=https://izones.cloud \
  -e TARGET_PATH='/api/flight?departure=ICN&arrival=NRT&passengers=1' \
  -e VUS=20 \
  -e DURATION=1m \
  /Users/ms/Desktop/workings/MZC_final_project/airline-eks/k6/simple-load.js
```

```bash
k6 run -e BASE_URL=https://izones.cloud k6/search.js
```

```bash
k6 run \
  -e BASE_URL=https://izones.cloud \
  -e USER_EMAIL=test1@example.com \
  -e USER_PASSWORD='change-me' \
  k6/auth.js
```

```bash
k6 run \
  -e BASE_URL=http://svc-auth.airline-auth.svc.cluster.local:3000 \
  -e AUTH_BURST_START_RATE=50 \
  -e AUTH_BURST_STEP_RATE=150 \
  -e AUTH_BURST_STEPS=6 \
  -e AUTH_BURST_STEP_DURATION=2m \
  -e AUTH_BURST_PRE_ALLOCATED_VUS=200 \
  -e AUTH_BURST_MAX_VUS=1200 \
  k6/auth-burst.js
```

```bash
k6 run \
  -e AUTH_BASE_URL=http://svc-auth.airline-auth.svc.cluster.local:3000 \
  -e SEARCH_BASE_URL=http://svc-flight.airline-flight.svc.cluster.local:3000 \
  -e AUTH_BURST_START_RATE=30 \
  -e AUTH_BURST_STEP_RATE=70 \
  -e AUTH_BURST_STEPS=5 \
  -e AUTH_BURST_STEP_DURATION=2m \
  -e SEARCH_BURST_START_RATE=50 \
  -e SEARCH_BURST_STEP_RATE=150 \
  -e SEARCH_BURST_STEPS=5 \
  -e SEARCH_BURST_STEP_DURATION=2m \
  -e SEARCH_DEPARTURE=ICN \
  -e SEARCH_ARRIVAL=NRT \
  -e SEARCH_DATE=2026-04-15 \
  k6/auth-search-mix.js
```

```bash
k6 run \
  -e BASE_URL=https://izones.cloud \
  -e USER_EMAILS='test1@example.com,test2@example.com,test3@example.com' \
  -e USER_PASSWORD='change-me' \
  -e CHECKOUT_DEPARTURE=ICN \
  -e CHECKOUT_ARRIVAL=NRT \
  -e TRAVEL_DATE=2026-04-15 \
  k6/checkout.js
```

```bash
k6 run \
  -e BASE_URL=https://izones.cloud \
  -e USER_EMAIL=test1@example.com \
  -e USER_PASSWORD='change-me' \
  k6/mypage.js
```

## Useful env vars

- `REQUEST_TIMEOUT=10s`
- `SEARCH_RATE=20`
- `AUTH_RATE=5`
- `AUTH_BURST_START_RATE=50`
- `AUTH_BURST_STEP_RATE=100`
- `AUTH_BURST_STEPS=5`
- `AUTH_BURST_STEP_DURATION=2m`
- `AUTH_BURST_PRE_ALLOCATED_VUS=100`
- `AUTH_BURST_MAX_VUS=1000`
- `AUTH_BASE_URL=http://svc-auth.airline-auth.svc.cluster.local:3000`
- `SEARCH_BURST_START_RATE=50`
- `SEARCH_BURST_STEP_RATE=150`
- `SEARCH_BURST_STEPS=5`
- `SEARCH_BURST_STEP_DURATION=2m`
- `SEARCH_BURST_PRE_ALLOCATED_VUS=150`
- `SEARCH_BURST_MAX_VUS=1200`
- `SEARCH_BASE_URL=http://svc-flight.airline-flight.svc.cluster.local:3000`
- `CHECKOUT_RATE=2`
- `MYPAGE_RATE=5`
- `TARGET_PATH=/api/flight?departure=ICN&arrival=NRT&passengers=1`
- `VUS=20`
- `DURATION=1m`
- `SLEEP_SECONDS=1`
- `SEARCH_DEPARTURE=ICN`
- `SEARCH_ARRIVAL=NRT`
- `TRAVEL_DATE=2026-04-15`
- `CHECKOUT_PASSENGERS=1`
- `ALLOW_PAYMENT_CONFLICTS=true`
- `FLIGHT_IDS=1,2,3`
