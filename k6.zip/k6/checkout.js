import http from 'k6/http';
import { check } from 'k6';
import {
  AIRPORT_FEE,
  BASE_URL,
  DEFAULT_TRAVEL_DATE,
  SURCHARGE,
  buildPassengers,
  buildQuery,
  ensureCredentials,
  getVuCredentials,
  jsonParams,
  login,
  parseBooleanEnv,
  parseListEnv,
  parseNumberEnv,
  randomItem,
  readJson,
  think,
  totalAmount,
} from './common.js';

const checkoutRate = parseNumberEnv('CHECKOUT_RATE', 2);
const preAllocatedVUs = parseNumberEnv('CHECKOUT_PRE_ALLOCATED_VUS', 5);
const maxVUs = parseNumberEnv('CHECKOUT_MAX_VUS', 20);
const duration = __ENV.CHECKOUT_DURATION || '2m';
const passengerCount = parseNumberEnv('CHECKOUT_PASSENGERS', 1);
const allowPaymentConflicts = parseBooleanEnv('ALLOW_PAYMENT_CONFLICTS', true);
const candidateFlightIds = parseListEnv('FLIGHT_IDS', []);

ensureCredentials();

const searchParams = {
  departure: __ENV.CHECKOUT_DEPARTURE || __ENV.SEARCH_DEPARTURE || 'ICN',
  arrival: __ENV.CHECKOUT_ARRIVAL || __ENV.SEARCH_ARRIVAL || 'NRT',
  date: __ENV.CHECKOUT_DATE || DEFAULT_TRAVEL_DATE,
  passengers: passengerCount,
};

export const options = {
  scenarios: {
    checkout: {
      executor: 'constant-arrival-rate',
      rate: checkoutRate,
      timeUnit: '1s',
      duration,
      preAllocatedVUs,
      maxVUs,
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.02'],
    checks: ['rate>0.98'],
    'http_req_duration{endpoint:checkout-search}': ['p(95)<400'],
    'http_req_duration{endpoint:checkout-flight-detail}': ['p(95)<500'],
    'http_req_duration{endpoint:create-payment}': ['p(95)<2000'],
    'http_req_duration{endpoint:payment-detail}': ['p(95)<600'],
  },
};

function searchFlights() {
  const response = http.get(
    `${BASE_URL}/api/flight${buildQuery(searchParams)}`,
    jsonParams({ endpoint: 'checkout-search' })
  );

  const body = readJson(response);
  return {
    response,
    body: Array.isArray(body) ? body : [],
  };
}

function getFlightDetail(flightId) {
  const response = http.get(
    `${BASE_URL}/api/flight/${flightId}`,
    jsonParams({ endpoint: 'checkout-flight-detail' })
  );

  return {
    response,
    body: readJson(response),
  };
}

function createPayment(token, flight, passengers) {
  const payload = {
    flightId: flight.id,
    date: searchParams.date,
    passengers,
    totalAmount: totalAmount(flight.price, passengers.length),
  };

  const response = http.post(
    `${BASE_URL}/api/payment`,
    JSON.stringify(payload),
    jsonParams({ endpoint: 'create-payment' }, token)
  );

  return {
    response,
    body: readJson(response),
  };
}

function loadPayment(token, paymentId) {
  return http.get(
    `${BASE_URL}/api/payment/${paymentId}`,
    jsonParams({ endpoint: 'payment-detail' }, token)
  );
}

export default function () {
  const credentials = getVuCredentials();
  const loginResult = login(credentials);

  check(loginResult.response, {
    'checkout login status is 200': (response) => response.status === 200,
    'checkout login returns token': () => Boolean(loginResult.token),
  });

  if (!loginResult.token) {
    return;
  }

  const searchResult = searchFlights();
  check(searchResult.response, {
    'checkout search status is 200': (response) => response.status === 200,
    'checkout search returns an array': () => Array.isArray(searchResult.body),
  });

  let selectedFlight = randomItem(searchResult.body);
  if (!selectedFlight && candidateFlightIds.length > 0) {
    selectedFlight = { id: randomItem(candidateFlightIds) };
  }

  if (!selectedFlight) {
    return;
  }

  const detailResult = getFlightDetail(selectedFlight.id);
  check(detailResult.response, {
    'checkout detail status is 200': (response) => response.status === 200,
    'checkout detail returns price': () => detailResult.body && Number(detailResult.body.price) > 0,
  });

  if (!detailResult.body) {
    return;
  }

  const passengers = buildPassengers(passengerCount);
  const paymentResult = createPayment(loginResult.token, detailResult.body, passengers);
  const acceptedStatuses = allowPaymentConflicts ? [201, 409] : [201];

  check(paymentResult.response, {
    'payment status is accepted': (response) => acceptedStatuses.includes(response.status),
    'payment response is json': () => paymentResult.body && typeof paymentResult.body === 'object',
  });

  if (paymentResult.response.status !== 201 || !paymentResult.body || !paymentResult.body.id) {
    think();
    return;
  }

  const paymentDetailResponse = loadPayment(loginResult.token, paymentResult.body.id);
  const paymentDetailBody = readJson(paymentDetailResponse);

  check(paymentDetailResponse, {
    'payment detail status is 200': (response) => response.status === 200,
    'payment detail is completed': () => paymentDetailBody && paymentDetailBody.status === 'completed',
  });

  think(0.5, 1.5);
}

export function handleSummary(data) {
  return {
    stdout: [
      `checkout summary`,
      `passengerCount=${passengerCount}`,
      `fareComponents=price+${SURCHARGE}+${AIRPORT_FEE}`,
      JSON.stringify(data.metrics.http_req_failed || {}, null, 2),
    ].join('\n'),
  };
}
