import { check } from 'k6';
import {
  ensureCredentials,
  getProfile,
  getVuCredentials,
  login,
  logout,
  parseNumberEnv,
  readJson,
  think,
} from './common.js';

const authRate = parseNumberEnv('AUTH_RATE', 5);
const preAllocatedVUs = parseNumberEnv('AUTH_PRE_ALLOCATED_VUS', 10);
const maxVUs = parseNumberEnv('AUTH_MAX_VUS', 30);
const duration = __ENV.AUTH_DURATION || '2m';

ensureCredentials();

export const options = {
  scenarios: {
    auth_flow: {
      executor: 'constant-arrival-rate',
      rate: authRate,
      timeUnit: '1s',
      duration,
      preAllocatedVUs,
      maxVUs,
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.01'],
    checks: ['rate>0.99'],
    'http_req_duration{endpoint:auth-login}': ['p(95)<500'],
    'http_req_duration{endpoint:auth-profile}': ['p(95)<400'],
    'http_req_duration{endpoint:auth-logout}': ['p(95)<400'],
  },
};

export default function () {
  const credentials = getVuCredentials();
  const loginResult = login(credentials);

  check(loginResult.response, {
    'login status is 200': (response) => response.status === 200,
    'login returns token': () => Boolean(loginResult.token),
  });

  if (!loginResult.token) {
    return;
  }

  const profileResponse = getProfile(loginResult.token);
  const profileBody = readJson(profileResponse);

  check(profileResponse, {
    'profile status is 200': (response) => response.status === 200,
    'profile email matches test user': () => profileBody && profileBody.email === credentials.email,
  });

  const logoutResponse = logout(loginResult.token);

  check(logoutResponse, {
    'logout status is 200': (response) => response.status === 200,
  });

  think();
}
