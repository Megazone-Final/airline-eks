import http from 'k6/http';
import { check } from 'k6';
import {
  BASE_URL,
  DEFAULT_TRAVEL_DATE,
  buildQuery,
  jsonParams,
  parseNumberEnv,
  randomItem,
  readJson,
  think,
} from './common.js';

const searchRate = parseNumberEnv('SEARCH_RATE', 20);
const preAllocatedVUs = parseNumberEnv('SEARCH_PRE_ALLOCATED_VUS', 20);
const maxVUs = parseNumberEnv('SEARCH_MAX_VUS', 100);
const duration = __ENV.SEARCH_DURATION || '2m';
const passengers = parseNumberEnv('SEARCH_PASSENGERS', 1);

const defaultSearchParams = {
  departure: __ENV.SEARCH_DEPARTURE || 'ICN',
  arrival: __ENV.SEARCH_ARRIVAL || 'NRT',
  date: __ENV.SEARCH_DATE || DEFAULT_TRAVEL_DATE,
  passengers,
};

export const options = {
  scenarios: {
    search: {
      executor: 'constant-arrival-rate',
      rate: searchRate,
      timeUnit: '1s',
      duration,
      preAllocatedVUs,
      maxVUs,
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.01'],
    checks: ['rate>0.99'],
    'http_req_duration{endpoint:search-flights}': ['p(95)<300'],
    'http_req_duration{endpoint:flight-detail}': ['p(95)<400'],
  },
};

export default function () {
  const searchResponse = http.get(
    `${BASE_URL}/api/flight${buildQuery(defaultSearchParams)}`,
    jsonParams({ endpoint: 'search-flights' })
  );

  const searchBody = readJson(searchResponse);
  const flights = Array.isArray(searchBody) ? searchBody : [];

  check(searchResponse, {
    'search status is 200': (response) => response.status === 200,
    'search returns an array': () => Array.isArray(searchBody),
  });

  if (flights.length === 0) {
    think();
    return;
  }

  const flight = randomItem(flights);
  const detailResponse = http.get(
    `${BASE_URL}/api/flight/${flight.id}`,
    jsonParams({ endpoint: 'flight-detail' })
  );
  const detailBody = readJson(detailResponse);

  check(detailResponse, {
    'detail status is 200': (response) => response.status === 200,
    'detail flight id matches': () => detailBody && Number(detailBody.id) === Number(flight.id),
  });

  think();
}

