import http from 'k6/http';
import { check } from 'k6';
import {
  BASE_URL,
  ensureCredentials,
  getVuCredentials,
  jsonParams,
  login,
  parseNumberEnv,
  readJson,
  think,
} from './common.js';

const mypageRate = parseNumberEnv('MYPAGE_RATE', 5);
const preAllocatedVUs = parseNumberEnv('MYPAGE_PRE_ALLOCATED_VUS', 10);
const maxVUs = parseNumberEnv('MYPAGE_MAX_VUS', 30);
const duration = __ENV.MYPAGE_DURATION || '2m';

ensureCredentials();

export const options = {
  scenarios: {
    mypage: {
      executor: 'constant-arrival-rate',
      rate: mypageRate,
      timeUnit: '1s',
      duration,
      preAllocatedVUs,
      maxVUs,
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.01'],
    checks: ['rate>0.99'],
    'http_req_duration{endpoint:mypage-reservations}': ['p(95)<500'],
    'http_req_duration{endpoint:mypage-payments}': ['p(95)<500'],
  },
};

export default function () {
  const credentials = getVuCredentials();
  const loginResult = login(credentials);

  check(loginResult.response, {
    'mypage login status is 200': (response) => response.status === 200,
    'mypage login returns token': () => Boolean(loginResult.token),
  });

  if (!loginResult.token) {
    return;
  }

  const requests = [
    [
      'GET',
      `${BASE_URL}/api/flight/reservations`,
      null,
      jsonParams({ endpoint: 'mypage-reservations' }, loginResult.token),
    ],
    [
      'GET',
      `${BASE_URL}/api/payment`,
      null,
      jsonParams({ endpoint: 'mypage-payments' }, loginResult.token),
    ],
  ];

  const [reservationsResponse, paymentsResponse] = http.batch(requests);
  const reservationsBody = readJson(reservationsResponse);
  const paymentsBody = readJson(paymentsResponse);

  check(reservationsResponse, {
    'reservations status is 200': (response) => response.status === 200,
    'reservations returns an array': () => Array.isArray(reservationsBody),
  });

  check(paymentsResponse, {
    'payments status is 200': (response) => response.status === 200,
    'payments returns an array': () => Array.isArray(paymentsBody),
  });

  think();
}
