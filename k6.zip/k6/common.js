import http from 'k6/http';
import { sleep } from 'k6';

export const BASE_URL = (__ENV.BASE_URL || 'https://izones.cloud').replace(/\/+$/, '');
export const REQUEST_TIMEOUT = __ENV.REQUEST_TIMEOUT || '10s';
export const SURCHARGE = parseNumberEnv('SURCHARGE', 28000);
export const AIRPORT_FEE = parseNumberEnv('AIRPORT_FEE', 17000);
export const DEFAULT_TRAVEL_DATE = __ENV.TRAVEL_DATE || buildFutureDate(30);

export function parseNumberEnv(name, fallback) {
  const raw = __ENV[name];
  if (raw === undefined || raw === null || raw === '') {
    return fallback;
  }

  const value = Number(raw);
  return Number.isFinite(value) ? value : fallback;
}

export function parseBooleanEnv(name, fallback = false) {
  const raw = (__ENV[name] || '').trim().toLowerCase();
  if (!raw) {
    return fallback;
  }

  return ['1', 'true', 'yes', 'y', 'on'].includes(raw);
}

export function parseListEnv(name, fallback = []) {
  const raw = __ENV[name];
  if (!raw) {
    return fallback;
  }

  return raw
    .split(',')
    .map((value) => value.trim())
    .filter(Boolean);
}

export function buildFutureDate(offsetDays) {
  const target = new Date();
  target.setDate(target.getDate() + offsetDays);
  return target.toISOString().slice(0, 10);
}

export function buildQuery(params) {
  const entries = Object.entries(params).filter(([, value]) => {
    return value !== undefined && value !== null && value !== '';
  });

  if (entries.length === 0) {
    return '';
  }

  return `?${entries
    .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`)
    .join('&')}`;
}

export function jsonParams(tags = {}, token = '') {
  const headers = {
    'Content-Type': 'application/json',
  };

  if (token) {
    headers.Authorization = `Bearer ${token}`;
  }

  return {
    headers,
    tags,
    timeout: REQUEST_TIMEOUT,
  };
}

export function readJson(response) {
  try {
    return response.json();
  } catch (error) {
    return null;
  }
}

export function randomItem(items) {
  if (!Array.isArray(items) || items.length === 0) {
    return null;
  }

  return items[Math.floor(Math.random() * items.length)];
}

export function randomBetween(min, max) {
  return min + Math.random() * (max - min);
}

export function think(min = 0.2, max = 1.0) {
  sleep(randomBetween(min, max));
}

export function getUserPool() {
  const emails = parseListEnv('USER_EMAILS', []);
  if (emails.length > 0) {
    return emails;
  }

  if (__ENV.USER_EMAIL) {
    return [__ENV.USER_EMAIL.trim()];
  }

  return [];
}

export function ensureCredentials() {
  const emails = getUserPool();
  if (emails.length === 0) {
    throw new Error('Set USER_EMAIL or USER_EMAILS before running this script.');
  }

  if (!__ENV.USER_PASSWORD) {
    throw new Error('Set USER_PASSWORD before running this script.');
  }

  return {
    emails,
    password: __ENV.USER_PASSWORD,
  };
}

export function getVuCredentials() {
  const { emails, password } = ensureCredentials();
  const email = emails[(__VU - 1) % emails.length];
  return { email, password };
}

export function login(credentials = getVuCredentials(), tags = {}) {
  const response = http.post(
    `${BASE_URL}/api/auth/users/login`,
    JSON.stringify(credentials),
    jsonParams({ endpoint: 'auth-login', ...tags })
  );

  const body = readJson(response);
  const token = body && typeof body === 'object' ? body.token : '';

  return {
    response,
    body,
    token,
  };
}

export function logout(token, tags = {}) {
  return http.post(
    `${BASE_URL}/api/auth/users/logout`,
    JSON.stringify({}),
    jsonParams({ endpoint: 'auth-logout', ...tags }, token)
  );
}

export function getProfile(token, tags = {}) {
  return http.get(
    `${BASE_URL}/api/auth/users/profile`,
    jsonParams({ endpoint: 'auth-profile', ...tags }, token)
  );
}

export function buildPassengers(count) {
  const passengers = [];

  for (let index = 0; index < count; index += 1) {
    const suffix = `${__VU}${__ITER}${index}${Date.now().toString(36)}`.toUpperCase();
    const birthYear = 1985 + ((index + __VU + __ITER) % 15);
    const birthMonth = String((index % 12) + 1).padStart(2, '0');
    const birthDay = String(((index + 10) % 28) + 1).padStart(2, '0');
    passengers.push({
      lastName: `TEST${index + 1}`,
      firstName: `VU${__VU}I${__ITER}`,
      birth: `${birthYear}-${birthMonth}-${birthDay}`,
      gender: index % 2 === 0 ? 'M' : 'F',
      passport: `M${suffix}`.slice(0, 9),
      nationality: 'KR',
    });
  }

  return passengers;
}

export function totalAmount(price, passengerCount) {
  return (Number(price) + SURCHARGE + AIRPORT_FEE) * passengerCount;
}
