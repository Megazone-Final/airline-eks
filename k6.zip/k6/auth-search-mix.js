import http from 'k6/http';
import { check } from 'k6';
import {
  DEFAULT_TRAVEL_DATE,
  REQUEST_TIMEOUT,
  buildQuery,
  jsonParams,
  parseNumberEnv,
  randomItem,
  readJson,
} from './common.js';

const defaultBaseUrl = (__ENV.BASE_URL || 'https://izones.cloud').replace(/\/+$/, '');
const authBaseUrl = (__ENV.AUTH_BASE_URL || defaultBaseUrl).replace(/\/+$/, '');
const searchBaseUrl = (__ENV.SEARCH_BASE_URL || defaultBaseUrl).replace(/\/+$/, '');

const authStartRate = parseNumberEnv('AUTH_BURST_START_RATE', 30);
const authStepRate = parseNumberEnv('AUTH_BURST_STEP_RATE', 70);
const authSteps = parseNumberEnv('AUTH_BURST_STEPS', 5);
const authStepDuration = __ENV.AUTH_BURST_STEP_DURATION || '2m';
const authPreAllocatedVUs = parseNumberEnv('AUTH_BURST_PRE_ALLOCATED_VUS', 100);
const authMaxVUs = parseNumberEnv('AUTH_BURST_MAX_VUS', 1000);
const loginEmail = (__ENV.LOGIN_EMAIL || 'loadtest-nonexistent@izones.cloud').trim();
const loginPassword = __ENV.LOGIN_PASSWORD || 'wrong-password';

const searchStartRate = parseNumberEnv('SEARCH_BURST_START_RATE', 50);
const searchStepRate = parseNumberEnv('SEARCH_BURST_STEP_RATE', 150);
const searchSteps = parseNumberEnv('SEARCH_BURST_STEPS', 5);
const searchStepDuration = __ENV.SEARCH_BURST_STEP_DURATION || '2m';
const searchPreAllocatedVUs = parseNumberEnv('SEARCH_BURST_PRE_ALLOCATED_VUS', 150);
const searchMaxVUs = parseNumberEnv('SEARCH_BURST_MAX_VUS', 1200);
const searchPassengers = parseNumberEnv('SEARCH_PASSENGERS', 1);

const defaultSearchParams = {
  departure: __ENV.SEARCH_DEPARTURE || 'ICN',
  arrival: __ENV.SEARCH_ARRIVAL || 'NRT',
  date: __ENV.SEARCH_DATE || DEFAULT_TRAVEL_DATE,
  passengers: searchPassengers,
};

function buildStages(startRate, stepRate, steps, stepDuration) {
  return Array.from({ length: Math.max(1, steps) }, (_, index) => {
    return {
      target: startRate + stepRate * (index + 1),
      duration: stepDuration,
    };
  });
}

export const options = {
  discardResponseBodies: true,
  scenarios: {
    auth_login_burst: {
      executor: 'ramping-arrival-rate',
      exec: 'authLoginBurst',
      startRate: authStartRate,
      timeUnit: '1s',
      preAllocatedVUs: authPreAllocatedVUs,
      maxVUs: authMaxVUs,
      stages: buildStages(authStartRate, authStepRate, authSteps, authStepDuration),
    },
    public_search_burst: {
      executor: 'ramping-arrival-rate',
      exec: 'publicSearchBurst',
      startRate: searchStartRate,
      timeUnit: '1s',
      preAllocatedVUs: searchPreAllocatedVUs,
      maxVUs: searchMaxVUs,
      stages: buildStages(searchStartRate, searchStepRate, searchSteps, searchStepDuration),
    },
  },
  thresholds: {
    http_req_failed: ['rate<0.05'],
    checks: ['rate>0.95'],
    'http_req_duration{endpoint:auth-login-burst}': ['p(95)<1500'],
    'http_req_duration{endpoint:search-flights-burst}': ['p(95)<800'],
    'http_req_duration{endpoint:flight-detail-burst}': ['p(95)<1000'],
  },
};

export function authLoginBurst() {
  const response = http.post(
    `${authBaseUrl}/api/auth/users/login`,
    JSON.stringify({
      email: loginEmail,
      password: loginPassword,
    }),
    {
      headers: {
        'Content-Type': 'application/json',
      },
      tags: {
        endpoint: 'auth-login-burst',
      },
      timeout: REQUEST_TIMEOUT,
    }
  );

  check(response, {
    'auth login returns 200 or 401': (res) => res.status === 200 || res.status === 401,
  });
}

export function publicSearchBurst() {
  const searchResponse = http.get(
    `${searchBaseUrl}/api/flight${buildQuery(defaultSearchParams)}`,
    jsonParams({ endpoint: 'search-flights-burst' })
  );

  const searchBody = readJson(searchResponse);
  const flights = Array.isArray(searchBody) ? searchBody : [];

  check(searchResponse, {
    'search status is 200': (response) => response.status === 200,
    'search returns an array': () => Array.isArray(searchBody),
  });

  if (flights.length === 0) {
    return;
  }

  const flight = randomItem(flights);
  const detailResponse = http.get(
    `${searchBaseUrl}/api/flight/${flight.id}`,
    jsonParams({ endpoint: 'flight-detail-burst' })
  );
  const detailBody = readJson(detailResponse);

  check(detailResponse, {
    'detail status is 200': (response) => response.status === 200,
    'detail flight id matches': () => detailBody && Number(detailBody.id) === Number(flight.id),
  });
}
